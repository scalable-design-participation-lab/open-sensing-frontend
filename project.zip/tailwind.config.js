/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {},
    colors: {
      transparent: 'transparent',
      gcfgreen: '#026341',
      gcfdarkgreen: '#004E32',
      gcfneon: '#DBFF00',
    },
  },
  plugins: [],
}
